from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.etudiant_form,name='etudiant_insert'),
    path('<int:id>/',views.etudiant_form,name='etudiant_update'),
    path('delete/<int:id>/',views.etudiant_delete,name='etudiant_delete'),
    path('suivi/',views.etudiant_list,name='etudiant_list')

]