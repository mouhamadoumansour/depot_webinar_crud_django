from django.shortcuts import render,redirect
from .models import Etudiant
from .forms import etudiantForm

# Create your views here.

def etudiant_list(request):
    ctx = {'etudiant_list':Etudiant.objects.all()}
    return render(request,"etudiantGestion/etudiant_list.html",ctx)

def etudiant_form(request,id=0):
    if request.method == "GET":
        if id==0:
            form = etudiantForm()
        else:
            etud = Etudiant.objects.get(pk=id)
            form = etudiantForm(instance=etud)
        return render(request,"etudiantGestion/etudiant_form.html",{'form':form})
    else:
        if id==0:
            form = etudiantForm(request.POST)
        else:
            etud = Etudiant.objects.get(pk=id)
            form = etudiantForm(request.POST,instance=etud)
        if form.is_valid():
            form.save()
        return redirect('/inscription/suivi/')

def etudiant_delete(request,id):
    supp = Etudiant.objects.get(pk=id)
    supp.delete()
    return redirect('/inscription/suivi/')


