from django.db import models

class Filiere(models.Model):
    nom_filiere = models.CharField(max_length=100)
    def __str__(self):
        return self.nom_filiere

class Etudiant(models.Model):
    ine = models.CharField(max_length=15)
    prenom = models.CharField(max_length=100)
    nom = models.CharField(max_length=100)
    date_nais = models.DateField(auto_now=False)
    lieu_nais = models.CharField(max_length=100)
    sexe = models.CharField(max_length=10)
    filiere = models.ForeignKey(Filiere,on_delete=models.CASCADE)
    
