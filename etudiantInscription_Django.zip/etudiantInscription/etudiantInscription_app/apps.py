from django.apps import AppConfig


class EtudiantinscriptionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'etudiantInscription_app'
