from django import forms
from .models import Etudiant

class etudiantForm(forms.ModelForm):
    class Meta:
        model = Etudiant
        fields = ('ine','prenom','nom','date_nais','lieu_nais','sexe','filiere')
        labels = {
            'ine':'Identifiant National Etudiant',
            'prenom':'Prénom (s)',
            'nom':'Nom',
            'date_nais':'Date de naissance',
            'lieu_nais':'Lieu de naissance',
            'sexe':'Sexe',
            'filiere':'Filière'
        }

    def __init__(self, *args, **kwargs):
        super(etudiantForm,self).__init__(*args, **kwargs)
        self.fields['filiere'].empty_label = "Selectionnez une filière : "
        self.fields['date_nais'].input_formats = ['%d/%m/%Y']